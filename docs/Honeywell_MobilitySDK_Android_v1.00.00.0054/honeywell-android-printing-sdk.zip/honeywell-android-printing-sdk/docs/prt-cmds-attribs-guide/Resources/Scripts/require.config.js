require.config({
    urlArgs: 't=635894892846382270'
});