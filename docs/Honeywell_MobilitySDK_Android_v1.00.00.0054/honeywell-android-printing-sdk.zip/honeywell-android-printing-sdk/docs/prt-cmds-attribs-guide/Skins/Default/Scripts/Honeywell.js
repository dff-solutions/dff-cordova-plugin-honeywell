$(document).ready(function(){
   $("div#header>a").attr("href", "http://www.honeywellaidc.com/");
});